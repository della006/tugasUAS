# Note Using Room Database

<h3 align="left">Light mode:</h3>
<p align="left"> 
<img src="https://github.com/rizkikurniaa/NoteUsingRoom/blob/master/ss-home-light.jpg" width="250"> <img src="https://github.com/rizkikurniaa/NoteUsingRoom/blob/master/ss-detail-light.jpg" width="250"> <img src="https://github.com/rizkikurniaa/NoteUsingRoom/blob/master/ss-edit-light.jpg" width="250">

<h3 align="left">Dark mode:</h3>
<p align="left"> 
<img src="https://github.com/rizkikurniaa/NoteUsingRoom/blob/master/ss-home-dark.jpg" width="250"> <img src="https://github.com/rizkikurniaa/NoteUsingRoom/blob/master/ss-detail-dark.jpg" width="250"> <img src="https://github.com/rizkikurniaa/NoteUsingRoom/blob/master/ss-edit-dark.jpg" width="250">

Implemented Room database and Neumorphism to Note Apps, built with Android studio using kotlin MVVM and view Binding

## Getting Started
- Fork or Clone the Repository
- Give a star if this repository useful